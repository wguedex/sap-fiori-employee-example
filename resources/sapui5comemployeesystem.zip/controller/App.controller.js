sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("sapui5.com.employeesystem.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map